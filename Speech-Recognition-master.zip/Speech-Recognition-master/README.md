Speech-Recognition
==================

A simple Matlab code to recognize people using their voice.

Based on http://www.ifp.illinois.edu/~minhdo/teaching/speaker_recognition/

All speakers uttered the same single digit "zero", once in a training session
and once in a testing session. The vocabulary of digits is commonly used in
speaker recognition systems. By checking the voice characteristics of the input
utterance, the system is able to add an extra level of security.
